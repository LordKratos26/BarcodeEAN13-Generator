﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Spire.Barcode;

namespace BarcodegeneratorEAN13
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string Barcode, Check12digits;

            if(textBox1.Text != "")
            {
                Check12digits = textBox1.Text.PadRight(12, '0');
                Barcode = EAN13.Barean(Check12digits);
                


                if (!String.Equals(EAN13.Barcode13Digits, "") || (EAN13.Barcode13Digits != ""))
                {
                    richtext.Text = EAN13.Barcode13Digits.ToString();
                    // Change Color of certain text in a RichTextBox.
                    Int32 intStart = Convert.ToInt32(richtext.TextLength - 1);
                    ChangeTextColor.ChangeColor(richtext, intStart);
                   
                   




                }


            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Adding barcode to PDF
            BarcodeSettings barsetting = new BarcodeSettings();
            barsetting.Data = richtext.Text;
            barsetting.Data2D = richtext.Text;
            //------------------------------------
            barsetting.Type = BarCodeType.EAN13;
            barsetting.ShowTextOnBottom = true;
            //------------------------------------
            BarCodeGenerator bargenerator = new BarCodeGenerator(barsetting);
            Image barcodeimage = bargenerator.GenerateImage();
            barcodeimage.Save(@"d:\barcode"+ DateTime.Now.ToString("yyyy-dd-M--HH-mm-ss")+ ".png");
        }
    }
}
